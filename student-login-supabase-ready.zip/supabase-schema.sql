-- منصة الفيزياء: إنشاء الجداول المطلوبة للصفحة
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'طالبة'
    check (char_length(display_name) <= 80),
  goal text not null default ''
    check (char_length(goal) <= 180),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.student_notes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid()
    references auth.users(id) on delete cascade,
  title text not null check (char_length(trim(title)) between 1 and 140),
  content text not null check (char_length(trim(content)) between 1 and 20000),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists student_notes_user_updated_idx
  on public.student_notes (user_id, updated_at desc);

create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

drop trigger if exists profiles_set_updated_at on public.profiles;
create trigger profiles_set_updated_at
before update on public.profiles
for each row execute function public.set_updated_at();

drop trigger if exists student_notes_set_updated_at on public.student_notes;
create trigger student_notes_set_updated_at
before update on public.student_notes
for each row execute function public.set_updated_at();

alter table public.profiles enable row level security;
alter table public.student_notes enable row level security;

drop policy if exists profiles_select_own on public.profiles;
create policy profiles_select_own on public.profiles
for select to authenticated using ((select auth.uid()) = user_id);

drop policy if exists profiles_insert_own on public.profiles;
create policy profiles_insert_own on public.profiles
for insert to authenticated with check ((select auth.uid()) = user_id);

drop policy if exists profiles_update_own on public.profiles;
create policy profiles_update_own on public.profiles
for update to authenticated using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

drop policy if exists profiles_delete_own on public.profiles;
create policy profiles_delete_own on public.profiles
for delete to authenticated using ((select auth.uid()) = user_id);

drop policy if exists student_notes_select_own on public.student_notes;
create policy student_notes_select_own on public.student_notes
for select to authenticated using ((select auth.uid()) = user_id);

drop policy if exists student_notes_insert_own on public.student_notes;
create policy student_notes_insert_own on public.student_notes
for insert to authenticated with check ((select auth.uid()) = user_id);

drop policy if exists student_notes_update_own on public.student_notes;
create policy student_notes_update_own on public.student_notes
for update to authenticated using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

drop policy if exists student_notes_delete_own on public.student_notes;
create policy student_notes_delete_own on public.student_notes
for delete to authenticated using ((select auth.uid()) = user_id);

revoke all on public.profiles from anon, authenticated;
revoke all on public.student_notes from anon, authenticated;
grant select, insert, update, delete on public.profiles to authenticated;
grant select, insert, update, delete on public.student_notes to authenticated;
