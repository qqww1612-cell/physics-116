إعداد صفحة تسجيل دخول الطالب مع Supabase

1) افتحي Supabase > SQL Editor > New query.
2) انسخي محتوى supabase-schema.sql كاملًا واضغطي Run.
3) افتحي student-login.html وابحثي عن SUPABASE_URL و SUPABASE_PUBLISHABLE_KEY وضعي رابط مشروعك والمفتاح العام فقط.
4) ارفعي student-login.html إلى مجلد المشروع الصحيح في GitHub Pages.
5) لا ترفعي service_role أو Secret key أو env.txt الذي يحتوي على أسرار.

هذه النسخة تستخدم public.profiles و public.student_notes. سياسات RLS تمنع المستخدم من قراءة أو تعديل صفوف مستخدم آخر.
